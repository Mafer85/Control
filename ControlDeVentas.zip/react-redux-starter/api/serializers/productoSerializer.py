from rest_framework import serializers
from api.models import Producto, Profile

class ProductoRegistroSerializer(serializers.ModelSerializer):
    class Meta:
        model = Producto
        fields = (
            'nombre',
            'precio',
        )

class Productoserializer(serializers.ModelSerializer):
    class Meta:
        model = Producto
        fields = (
            'id',
            'nombre',
            'precio',
            'archivo',
            'vendedor',
        )
        depth = 2
