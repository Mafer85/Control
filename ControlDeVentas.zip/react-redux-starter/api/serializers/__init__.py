from .user import UserSerializer, UserReadSerializer
from .productoSerializer import ProductoRegistroSerializer,Productoserializer 
