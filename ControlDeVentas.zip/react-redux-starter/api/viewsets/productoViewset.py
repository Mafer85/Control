import json
from django.db import transaction
from django.core.files import File
from django.core import serializers
from django.core.paginator import Paginator
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import status, filters, viewsets
from django.contrib.auth.models import User
from rest_framework.authtoken.models import Token
from rest_framework.decorators import action
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.settings import api_settings

from api.models import Producto, Profile
from api.serializers import ProductoRegistroSerializer, Productoserializer

class ProductoViewSet(viewsets.ModelViewSet):

    queryset = Producto.objects.filter(producto_activo=True)

    filter_backends = (DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter)
    filter_fields = ("nombre","precio")
    search_fields = ("nombre","precio")
    ordering_fields = ("nombre","precio")


    def get_serializer_class(self):
        if self.action == 'list' or self.action == 'retrieve':
            return Productoserializer
        else:
            return ProductoRegistroSerializer

    def get_permissions(self):

        if self.action == "create" or self.action == "token":
            permission_classes = [AllowAny]
        else:
            permission_classes = [IsAuthenticated]
        return [permission() for permission in permission_classes]


    def create(self,request, *args, **kwargs):
        try:
            data = request.data
            adjunto= data.get("adjunto")
            data = json.loads(data["data"])
            print("data: ",data)
            print("adjunto: ",adjunto)
            usuario =  request.user.profile.id
            print("vendedor ", usuario)
            serializer = ProductoRegistroSerializer(data = data)
            with transaction.atomic():
                if serializer.is_valid():
                    Producto.objects.create(
                        nombre = data.get("nombre"),
                        precio = data.get("precio"),
                        archivo = File(adjunto),
                        vendedor = usuario,
                    )
                    return Response(serializer.data, status=status.HTTP_200_OK)
                else:
                    return Response(serializer.errors, status = status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({"detail":str(e)},status=status.HTTP_400_BAD_REQUEST)


    #Listar los productos del usuario logueado
    @action(detail=False, methods=['get'])
    def productosVendedor(self, request):
        try:
            idvendedor = request.user.profile.id
            productos_vendedor = Producto.objects.filter(vendedor=idvendedor, producto_activo=True)
            page = self.paginate_queryset(productos_vendedor)
            if page is not None:
                serializer = Productoserializer(page, many=True)
                return self.get_paginated_response(serializer.data)

            serializer = Productoserializer(productos_vendedor, many=True)
            return Response(serializer.data)

        except Exception as e:
            return Response({'detail':str(e)}, status=status.HTTP_400_BAD_REQUEST);
