from django.db import models
from .profile import Profile

class Producto(models.Model):
    nombre = models.CharField(max_length=25)
    precio = models.FloatField()
    archivo = models.ImageField(upload_to='productos', null=True, blank=True)
    vendedor = models.ForeignKey(Profile, on_delete=models.CASCADE, related_name="producto_usuario", null=True, blank=True)
    producto_activo = models.BooleanField(default=True)

    def delete(self, *args):
        self.producto_activo = False
        if self.archivo is not None:
            self.archivo.delete()
        self.save()
        return True
        
