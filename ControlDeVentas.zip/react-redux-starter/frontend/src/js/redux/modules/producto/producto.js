import {handleActions} from 'redux-actions';
import { push } from "react-router-redux";
import {NotificationManager} from 'react-notifications';
import{api} from "../../../utility/api";
import { initialize as initializeForm } from 'redux-form';
const endpoint = "producto";
const SET_DATA_PRODUCTO = 'SET_DATA_PRODUCTO';
const SET_ITEM_PRODUCTO = 'SET_ITEM_PRODUCTO';

export const listar = (page=1) => (dispatch, getStore) => {
  const data = {
    page: page,
  }
  api.get('/producto/productosVendedor', data).then((response) => {
      dispatch({type: SET_DATA_PRODUCTO, data: response});
  }).catch((error) => {
    console.log("error: ", error);
    NotificationManager.error('Error al obtener los productos', 'ERROR', 0);
  }).finally(() => {

  });
}

export const crear = (formData,productos) => (dispatch, getStore) => {


  console.log("formData ", formData);
  console.log("productos ", productos);


  api.postAttachments('/producto', formData, productos).then(response => {
    console.log("Response: ", response);
    NotificationManager.success('Producto creado', 'Éxito', 3000);
    dispatch(push(`/producto`))
  }).catch((error) => {
    console.log("error: ", error);
    NotificationManager.error('Error en la creacion', 'ERROR', 0);
  }).finally(() => {

  });
}

export const editar = (formData,productos) => (dispatch, getStore) => {

  console.log("formData", formData)
  api.putAttachments(`${endpoint}/${formData.id}`, formData, productos).then(response => {
    console.log("Response: ", response);
    NotificationManager.success('Producto actualizado', 'Éxito', 3000);
    dispatch(push(`/${endpoint}`))
  }).catch((error) => {
    console.log("error: ", error);
    NotificationManager.error('Error en la edición', 'ERROR', 0);
  }).finally(() => {
  });
}

const leer = idproducto => (dispatch, getStore) => {
    api.get(`${endpoint}/${idproducto}`).then((response) => {
      console.log("Response: ", response);

      const formName = 'ProductoForm';
      if(!!getStore().form.ProductoForm)
        dispatch({type: SET_ITEM_PRODUCTO, item:response});

        dispatch(initializeForm(formName, response));
    }).catch((error) => {
      console.log("error: ", error)
    }).finally(() => {

    });
};

const eliminar = idproducto => (dispatch) => {
    api.eliminar(`${endpoint}/${idproducto}`).then(() => {

        NotificationManager.success('Producto eliminado', 'Éxito', 3000);
    }).catch(() => {
        NotificationManager.error('Error en la transacción', 'ERROR', 0);
    }).finally(() => {

    });
};

const clearItem = () => (dispatch) => {
  dispatch({type: SET_ITEM_PRODUCTO, item:null});
}
export const actions = {
  listar,
  crear,
  editar,
  leer,
  eliminar,
  clearItem,
}

export const reducers = {
  [SET_DATA_PRODUCTO]: (state, { data }) => {
    return {
      ...state,
      data,
    };
  },
  [SET_ITEM_PRODUCTO]: (state, { item }) => {
    return {
      ...state,
      item,
    }
  }

};

export const initialState = {
  data: {
      results: [],
      count: 0,
  },
};

export default handleActions(reducers, initialState);
