import React, { Component } from 'react';


class Demo2 extends Component {
    render() {
        return (
            <div>
                <span
                    className="text-uppercase page-subtitle">Escritorio ejemplo
                </span>
                <h3 className="page-title">Titulo secundario</h3>
            </div>
        );
    }
}

export default Demo2;
