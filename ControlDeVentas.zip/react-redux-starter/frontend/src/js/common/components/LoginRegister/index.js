export { Login } from "./Login";
export { default as Registro } from "./Register";
export { default as Profile } from "./Profile";
