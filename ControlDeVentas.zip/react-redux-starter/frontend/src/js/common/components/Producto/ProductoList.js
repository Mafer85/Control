import React, {Component} from 'react';
import Grid from "../Utils/Grid";
import NotificacionSweetForm from '../Examples/Notificaciones/NotificacionSweetForm';
import {standardActions } from '../Utils/Grid/StandardActions';
import { Link } from 'react-router-dom';
import Swal from 'sweetalert2';

class ProductoList extends Component{
  componentWillMount = () => {
    const {listar,page, editar, eliminar, leer} = this.props;
    listar(page);
  }

  eliminar = (idproducto) => {
      return () => {
          Swal.fire({
              title: '¿Eliminar?',
              text: '¡No podrá revertir esta acción!',
              type: 'warning',
              showCancelButton: true,
              confirmButtonText: '¡Sí, eliminar!',
              cancelButtonText: 'No, cancelar',
              reverseButtons: true
          }).then((result) => {
              if (result.value) {
                  this.props.eliminar(idproducto);
              }
          });
      }
  };

  render(){
    const {data, loader, eliminar,editar, leer} = this.props;
    console.log("data", this.id)
    return(
      <div >
      <h3>Productos</h3>
      <div className="d-flex flex-row justify-content-end mt-3">
      <a
        className="btn btn-primary btn-sm"
        href={`/#/producto/crear`}
      >
        Agregar producto
      </a>
      </div>
      {data &&
        <Grid
        hover striped data={data}
        loading={loader}
        //onPageChange={onPageChange}
        //onSortChange={onSortChange}
        >
            <TableHeaderColumn
                dataField="nombre"
                dataSort
            >
                Nombre
            </TableHeaderColumn>

            <TableHeaderColumn
                dataField="precio"
                dataSort
            >
                Precio
            </TableHeaderColumn>



            <TableHeaderColumn
                isKey
                dataField="id"
                dataAlign="center"
                dataSort
                dataFormat={(cell) => {
                  return (
                    <React.Fragment>
                    <Link
                      className="text-warning"
                      to={`/producto/editar/${cell}`} >
                      <i className="material-icons">edit</i>
                    </Link>

                    <Link
                      to={`/producto/ver/${cell}`}
                      className="px-2" >
                      <i className="material-icons">remove_red_eye</i>
                    </Link>

                    <a className="px-2"
                     style={{cursor: "pointer", color: "#c4183c"}}
                     onClick={this.eliminar(`${cell}`)}>
                     <i className="material-icons">delete</i>
                    </a>

                    </React.Fragment>
                  );
                }
                }
            >
                Acciones
            </TableHeaderColumn>
        </Grid>
       }
      </div>
    );
  }
}

export default ProductoList;
