import React, {Component} from 'react';
import Formulario from './Formulario';

class ProductoCrear extends Component{

  state={
    creacion: true,
    adjunto: null,
  }

  componentWillMount = () => {
    const {leer, match} = this.props;
    const id = match.params.idproducto;

    if(id){
      this.setState({creacion: false});
      leer(id);
    }
  }

  componentWillUnmount = () => {
    const { clearItem } = this.props;
    clearItem();
  }

  setArchivo = (archivo) => {
      this.setState({adjunto: archivo});
  }

  create = (data) => {
    const { crear } = this.props;
    crear({...data, adjunto: null}, [{"file": this.state.adjunto, "name": "adjunto"}]);
  }

  update = (data) => {
    const { editar } = this.props;
    editar({...data, adjunto: null}, [{"file": this.state.adjunto, "name": "adjunto"}]);
  }

  actualizar = (data) => {
    const {editar} = this.props;
    const id  = data.id;
    editar({...data, adjunto: null}, [{"file": this.state.adjunto, "name": "adjunto"}]);
  }

  render(){
    const {crear,create, item} = this.props;
    const{creacion} = this.state;
    const fun = creacion ? this.create : this.actualizar;
    console.log("item: ", item)
    console.log("creacion: ", creacion)
    console.log("Contenido archivo: ", this.state.archivo)
    return(

      <React.Fragment>
        <Formulario
          item={item}
          setArchivo={this.setArchivo}
          crear={creacion}
          onSubmit={fun}
        />
      </React.Fragment>
    );
  }
}

export default ProductoCrear;
