/*Formulario de producto*/
import React, {Component} from 'react';
import {Field,reduxForm } from 'redux-form';
import { renderField, renderCurrency} from "../Utils/renderField/renderField";
import { AsyncSelectField, renderFilePicker } from "../Utils/renderField/renderField";
import {renderDatePicker} from "../Utils/renderField/renderField";

class Formulario extends Component {

  render(){
    const {handleSubmit, crear, editar, setArchivo, item} = this.props;
    const ver = window.location.href.includes("ver");

    return(
      <form onSubmit={handleSubmit}>
        <h3>Agregar producto</h3>
        <label>Producto</label>
        <Field
        name='nombre'
        component={renderField}
        />
        <br/><br/>

        <label>Precio</label>
        <Field
        name='precio'
        component={renderCurrency}
        />
        <br/><br/>

        <label> Archivo</label>
        <Field
            photo={item ? item.archivo : null}
            name="adjunto"
            component={renderFilePicker}
            setFile={setArchivo}
        />

        {item &&
          <a href={item.archivo} target="_blank">Ver / Descargar</a>
        }
        <br/><br/>


        <div className="d-flexflex-row justify-content-end mt-3">
          {!ver &&
          <button className="btn btn-primary btn-sm" >
            {crear ? "Registrar" : "Actualizar"}
          </button>
          }

        </div>
      </form>
    );
  }
}

export default reduxForm({
  form: 'ProductoForm'
})(Formulario)
